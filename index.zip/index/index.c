#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "index.h"

void initBstTree (BstNode *root) {
    *root = NULL;
}

void initAvlTree (AvlNode *root) {
    *root = NULL;
}

int initTable (Table table) {
    initBstTree(&table->indexBST);
    initAvlTree(&table->indexAVL);
    table->dataFile = fopen("data.dat", "a+");
    table->indexBST = loadFileBST(table->indexBST, "indexBST.dat");
    table->indexAVL = loadFileAVL(table->indexAVL, "indexAVL.dat");
    if (table->dataFile != NULL)
        return 1;
    else
        return 0;
}

void finishTable (Table table) {
    fclose(table->dataFile);
    saveFileBST(table->indexBST, "indexBST.dat");
    saveFileAVL(table->indexAVL, "indexAVL.dat");
}

void addStudent (Table table, Student student) {
    if (table->dataFile != NULL) {
        AbstractData newIndexBST = (AbstractData)malloc(sizeof(struct Index));
        AbstractData newIndexAVL = (AbstractData)malloc(sizeof(struct Index));
        newIndexBST->keyBST = student->callNumber;
//         newIndexAVL->keyAVL = student->age;
        
        fseek(table->dataFile, 0L, SEEK_END);
        newIndexBST->indexBST = ftell(table->dataFile);
//         newIndexAVL->indexAVL = ftell(table->dataFile);
        
        char *studentDatas = "%s:%s:%d:%d:%d\n";
        fprintf(table->dataFile, studentDatas, student->name, student->motherName, student->classNumber, student->callNumber, student->age);
//         fprintf(table->dataFile, "NAME=%s", student->name);
//         fprintf(table->dataFile, "MOTHER=%s", student->motherName);
//         fprintf(table->dataFile, "CLASS_NUMBER=%d", student->classNumber);
//         fprintf(table->dataFile, "CALL_NUMBER=%d", student->callNumber);
//         fprintf(table->dataFile, "AGE=%d", student->age);
//         fprintf(table->dataFile, "#\n");
        
        table->indexBST = insertNodeBST(table->indexBST, newIndexBST);
        //table->indexAVL = insertNodeAVL(table->indexAVL, newIndexAVL);
    }
}

Student inputData () {
    Student new = (Student)malloc(sizeof(struct student));
    char* buffer = (char*)malloc(256 * sizeof(char));
    
    getchar();
    printf("Digite o nome do Aluno: ");
    fgets(buffer, 255, stdin);
    removeEnter(buffer);
    new->name = strdup(buffer);
    
    printf("Digite o nome da mae do aluno: ");
    fgets(buffer, 255, stdin);
    removeEnter(buffer);
    new->motherName = strdup(buffer);
    
    printf("Digite o numero da sala: ");
    scanf("%d", &new->classNumber);
    
    printf("Digite o numero da chamada: ");
    scanf("%d", &new->callNumber);
    
    printf("Digite a idade: ");
    scanf("%d", &new->age);
    
    return new;
}

void removeEnter (char *string) {
   string[strlen(string)-1] = '\0'; 
}

void saveFileBST (BstNode bstRoot, char *path) {
    FILE *file;
    file = fopen(path, "wb");
    
    if (file != NULL) {
        saveFileAuxBST(bstRoot, file);
        fclose(file);
    }
}

void saveFileAVL (AvlNode root, char *path) {
    FILE *file;
    file = fopen(path, "wb");
    
    if (file != NULL) {
        saveFileAuxAVL(root, file);
        fclose(file);
    }
}

void saveFileRB (RbNode root, char *path) {
    FILE *file;
    file = fopen(path, "wb");
    
    if (file != NULL) {
        saveFileAuxRB(root, file);
        fclose(file);
    }
}

void saveFileAuxBST (BstNode root, FILE *file) {
    if (root != NULL) {
        fwrite(root->data, sizeof(struct Index), 1, file);
        saveFileAuxBST(root->leftNode, file);
        saveFileAuxBST(root->rightNode, file);
    }
}

void saveFileAuxAVL (AvlNode root, FILE *file) {
    if (root != NULL) {
        fwrite(root->data, sizeof(struct Index), 1, file);
        saveFileAuxAVL(root->leftNode, file);
        saveFileAuxAVL(root->rightNode, file);
    }
}

void saveFileAuxRB (RbNode root, FILE *file) {
    if (root != NULL) {
        fwrite(root->data, sizeof(struct Index), 1, file);
        saveFileAuxRB(root->leftNode, file);
        saveFileAuxRB(root->rightNode, file);
    }
}

BstNode loadFileBST (BstNode root, char* path) {
    FILE *file;
    file = fopen(path, "rb");
    AbstractData temp;
    
    if (file != NULL) {
        temp = (AbstractData)malloc(sizeof(Index));

        while (fread(temp, sizeof(Index), 1, file)) {
            root = insertNodeBST(root, temp);
            temp = (AbstractData)malloc(sizeof(Index));
        }
        fclose(file);
        
    }
    return root;
}

AvlNode loadFileAVL (AvlNode root, char* path) {
    FILE *file;
    file = fopen(path, "rb");
    AbstractData temp;
    
    if (file != NULL) {
        temp = (AbstractData)malloc(sizeof(Index));

        while (fread(temp, sizeof(Index), 1, file)) {
            root = insertNodeAVL(root, temp);
            temp = (AbstractData)malloc(sizeof(Index));
        }
        fclose(file);
    }
    return root;
}

RbNode loadFileRB (RbNode root, char* path) {
    FILE *file;
    file = fopen(path, "rb");
    AbstractData temp;
    
    if (file != NULL) {
        temp = (AbstractData)malloc(sizeof(Index));

        while (fread(temp, sizeof(Index), 1, file)) {
            //root = insertNodeBST(root, temp);
            temp = (AbstractData)malloc(sizeof(Index));
        }
        fclose(file);
    }
    return root;
}

void printElement (BstNode root, Table table) {
    Student temp = (Student)malloc(sizeof(struct student));
    fseek(table->dataFile, root->data->indexBST, SEEK_SET);
    fread(temp, sizeof(struct student), 1, table->dataFile);
    printf("[Chave: %d, Nome: %s, Nome da mae: %s, Turma: %d, Numero da chamada: %d, Idade: %d]\n", root->data->keyBST, temp->name, temp->motherName, temp->classNumber, temp->callNumber, temp->age);
    free(temp);
}

BstNode insertNodeBST (BstNode root, AbstractData data) {
    if (root == NULL) {
        BstNode new = (BstNode)malloc(sizeof(struct bstNode));
        
        new->data = data;
        new->leftNode = NULL;
        new->rightNode = NULL;
        
        return new;
    } else {
        if (data->keyBST > root->data->keyBST) {
            root->rightNode = insertNodeBST(root->rightNode, data);
        } else {
            root->leftNode = insertNodeBST(root->leftNode, data);
        }
        return root;
    }
    
}

AvlNode insertNodeAVL (AvlNode root, AbstractData data) {
    return NULL;
}

void preOrderBst (BstNode root, Table table) {
    if (root != NULL) {
        printf("[%d]", root->data->keyBST);
 
//         printElement(root, table);
        preOrderBst(root->leftNode, table);

        preOrderBst(root->rightNode, table);

    }
}








