#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "index.h"

int main (int argc, char * argv[]) {
    int option;
    table table;
    initTable(&table);
    

    
    while (true) {
        scanf("%d", &option);
        
        switch (option) {
            int value;
            
            case 1:
                addStudent(&table ,inputData());
                break;
            case 2:
                
                break;
            case 3:
                preOrderBst(table.indexBST, &table);
                break;
            case 99:
                finishTable(&table);
                exit(0);
        }
    }
}
