#ifndef INDEX_H
#define INDEX_H

#include <stdio.h>

enum color{BLACK, RED, DOUBLE_BLACK};

typedef struct student {
    char * name;
    char * motherName;
    int classNumber;
    int callNumber;
    int age;
} student;

typedef student * Student;

typedef struct Index {
    int keyBST;
    int indexBST;
//     int keyAVL;
//     int keyRB;
//     int indexBST;
//     int indexAVL;
//     int indexRB;
} Index;

typedef Index * AbstractData;

typedef struct bstNode {
    AbstractData data;
    struct bstNode *leftNode;
    struct bstNode *rightNode;
} bstNode;

typedef bstNode * BstNode;

typedef struct avlNode {
    Student data;
    int balance;
    struct avlNode *leftNode;
    struct avlNode *rightNode;
} avlNode;

typedef avlNode * AvlNode;

typedef struct rbNode {
    Student data;
    enum color color;
    struct rbNode* leftNode;
    struct rbNode* rightNode;
    struct rbNode* father;
} rbNode;

typedef rbNode * RbNode;

typedef struct table {
    FILE *dataFile;
    BstNode indexBST;
    AvlNode indexAVL;
    RbNode indexRB;
} table;

typedef table * Table;

int initTable(Table table);

BstNode insertNodeBST(BstNode root, AbstractData data);

AvlNode insertNodeAVL(AvlNode root, AbstractData data);

BstNode deleteNodeBST(BstNode root, AbstractData data);

AvlNode deleteNodeAvl(AvlNode root, AbstractData data);

Student highestValue(BstNode root);

Student inputData();

BstNode loadFileBST(BstNode root, char *path);

AvlNode loadFileAVL(AvlNode root, char *path);

void finishTable(Table table);

void addStudent(Table table, Student student);

void initBstTree(BstNode *root);

void saveFileBST(BstNode root, char *path);

void saveFileAVL(AvlNode root, char *path);

void saveFileRB(RbNode root, char *path);

void saveFileAuxBST(BstNode root, FILE *file);

void saveFileAuxAVL(AvlNode root, FILE *file);

void saveFileAuxRB(RbNode root, FILE *file);

void removeEnter(char *string);

void printElement(BstNode bstNode, Table table);

void preOrderBst(BstNode bstRoot, Table table);

void inOrder(BstNode root, Table table);

void posOrder(BstNode root, Table table);

#endif
